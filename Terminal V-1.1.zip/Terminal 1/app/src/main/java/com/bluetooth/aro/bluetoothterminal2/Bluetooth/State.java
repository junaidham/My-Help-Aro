package com.bluetooth.aro.bluetoothterminal2.Bluetooth;

public class State {
    public static final int CONNECTED = 3;
    public static final int CONNECTING = 2;
    public static final int LISTEN = 1;
    public static final int NONE = 0;

}
