package com.bluetooth.aro.bluetoothterminal2;

import android.annotation.SuppressLint;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.CheckedTextView;
import java.util.ArrayList;
import java.util.List;

public class SetupItemAdapter extends BaseAdapter {
    private ArrayList<String> alItem;
    private LayoutInflater itemInflater;
    private List<Boolean> listShow;

    public SetupItemAdapter(Context c, ArrayList<String> alItem, List<Boolean> listShow) {
        this.itemInflater = LayoutInflater.from(c);
        this.listShow = listShow;
        this.alItem = alItem;
    }

    public int getCount() {
        return this.alItem.size();
    }

    @SuppressLint({"InflateParams"})
    public View getView(int position, View convertView, ViewGroup parent) {
        View vi = convertView;
        if (vi == null) {
            vi = itemInflater.inflate(R.layout.setup_item, null);
        }
        CheckedTextView chkBshow = (CheckedTextView) vi.findViewById(R.id.ctvItem);
        chkBshow.setText((CharSequence) this.alItem.get(position));
        chkBshow.setChecked(((Boolean) this.listShow.get(position)).booleanValue());
        return vi;
    }

    public Object getItem(int arg0) {
        return this.alItem.get(arg0);
    }

    public long getItemId(int arg0) {
        return (long) arg0;
    }
}
