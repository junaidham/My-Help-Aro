package com.bluetooth.aro.bluetoothterminal2;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Message;
import android.text.format.DateFormat;
import android.util.Log;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.inputmethod.EditorInfo;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.TextView.OnEditorActionListener;
import android.widget.Toast;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.lang.ref.WeakReference;
import java.util.Date;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.bluetooth.aro.bluetoothterminal2.Bluetooth.Common;
import com.bluetooth.aro.bluetoothterminal2.Bluetooth.Service;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import com.bluetooth.aro.bluetoothterminal2.Bluetooth.Debug;
import com.bluetooth.aro.bluetoothterminal2.Bluetooth.State;

import com.bluetooth.aro.bluetoothterminal2.Configuration;
import com.bluetooth.aro.bluetoothterminal2.ContentAdapter;
import com.bluetooth.aro.bluetoothterminal2.DeviceListActivity;
import com.bluetooth.aro.bluetoothterminal2.SetupActivity;


import static android.bluetooth.BluetoothAdapter.SCAN_MODE_CONNECTABLE_DISCOVERABLE;
import static android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON;
import static android.widget.Toast.LENGTH_SHORT;
import static com.bluetooth.aro.bluetoothterminal2.Bluetooth.Message.*;
import static com.bluetooth.aro.bluetoothterminal2.Bluetooth.State.*;


public class MainActivity extends Activity {
    private static final int REQUEST_CONNECT_DEVICE_INSECURE = 2;
    private static final int REQUEST_CONNECT_DEVICE_SECURE = 1;
    private static final int REQUEST_ENABLE_BT = 3;
    private static final int REQUEST_SAVE_SETUP = 4;
    private BluetoothAdapter mBluetoothAdapter = null;
    private Configuration mConfiguration = null;
    //private String mConnectedDeviceName = "none";
    private String mConnectedDeviceName, mConnectedDeviceAddress;
    private ContentAdapter mConversationArrayAdapter;
    private ListView mConversationView;
    private EditText mOutEditText;
    private StringBuffer mOutStringBuffer;
    private Button mSendButton;
    private Service mService = null;


    /**
 * C00031 : BluetoothTerminal.MainActivity.1
 * The action listener for the EditText widget, to listen for the return key
*/
    private TextView.OnEditorActionListener mWriteListener = new TextView.OnEditorActionListener() {
        public boolean onEditorAction(TextView view, int actionId, KeyEvent event) {
            // If the action is a key-up event on the return key, send the message
            if (actionId == EditorInfo.IME_NULL && event.getAction() == KeyEvent.ACTION_UP) {
                String message = view.getText().toString();
                sendMessage(message);
            }
           // if(D) Log.i(TAG, "END onEditorAction");
            return true;
        }
    };



    public static <T> T IsNull(T objectToCheck, T defaultValue) {
        return objectToCheck == null ? defaultValue : objectToCheck;
    }



    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        setTitle(R.string.app_name);
        mBluetoothAdapter = BluetoothAdapter.getDefaultAdapter();

        // Device does not support Bluetooth
        if (this.mBluetoothAdapter == null) {
            //Toast.makeText(getApplicationContext(), "Bluetooth is not available", REQUEST_CONNECT_DEVICE_SECURE).show();
            Toast.makeText(this, "Bluetooth is not available", LENGTH_SHORT).show();
            finish();
            return;
        }
        mConfiguration = new Configuration(this);
        if (mConfiguration.getKeepScreenOn()) {
            getWindow().addFlags(FLAG_KEEP_SCREEN_ON);
        }
    }

    @Override
    public void onStart() {
        super.onStart();
        if (!mBluetoothAdapter.isEnabled()) {
            Intent enableBtIntent = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
            startActivityForResult(enableBtIntent, REQUEST_ENABLE_BT);
            // startActivityForResult(new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE), REQUEST_ENABLE_BT);  //"android.bluetooth.adapter.action.REQUEST_ENABLE"

        } else if (mService == null) {
            setupService();
        }
    }

    @Override
    public synchronized void onResume() {
        super.onResume();
        if (mService != null && mService.getState() == NONE) {
            mService.start();
        }
    }

    private void setupService() {
        mConversationArrayAdapter = new ContentAdapter(this);  //   mConversationArrayAdapter = new ArrayAdapter<String>(this, R.layout.message);
        mConversationView = (ListView) findViewById(R.id.in);

       // mConversationView.setAdapter(mConversationArrayAdapter);

        // Initialize the compose field with a listener for the return key
        mOutEditText = (EditText) findViewById(R.id.edit_text_out);
        mOutEditText.setOnEditorActionListener(mWriteListener);

        // Initialize the send button with a listener that for click events
        mSendButton = (Button) findViewById(R.id.button_send);
        mSendButton.setOnClickListener(new OnClickListener() {
            public void onClick(View v) {
                // Send a message using content of the edit text widget
                TextView view = (TextView) findViewById(R.id.edit_text_out);
                String message = view.getText().toString();
                sendMessage(message);
                /* C00042 : BluetoothTerminal.MainActivity.2 */
                //MainActivity.this.sendMessage(((TextView) MainActivity.this.findViewById(R.id.edit_text_out)).getText().toString());
            }
        });
        // Initialize the BluetoothChatService to perform bluetooth connections
        mService = new Service(this, new HandlerClass(this));
        // Initialize the buffer for outgoing messages
        mOutStringBuffer = new StringBuffer("");
    }



    @Override
    public synchronized void onPause() {
        super.onPause();
    }


    @Override
    public void onStop() {
        super.onStop();
    }


    @Override
    public void onDestroy() {
        super.onDestroy();
        if (mService != null) {
            mService.stop();
        }
    }



    private void ensureDiscoverable() {
        if (mBluetoothAdapter.getScanMode() != SCAN_MODE_CONNECTABLE_DISCOVERABLE) {
            Intent discoverableIntent = new Intent(BluetoothAdapter.ACTION_REQUEST_DISCOVERABLE);  //"android.bluetooth.adapter.action.REQUEST_DISCOVERABLE"
            discoverableIntent.putExtra(BluetoothAdapter.EXTRA_DISCOVERABLE_DURATION, 300); // "android.bluetooth.adapter.extra.DISCOVERABLE_DURATION"
            startActivity(discoverableIntent);
        }
    }

    private void sendMessage(String message) {
       // if (mService.getState() != REQUEST_ENABLE_BT) {
        if (mService.getState() != State.CONNECTED ) {
            Toast.makeText(this, R.string.not_connected, LENGTH_SHORT).show();
            return;
        }
        else if (message.length() > 0) {
            Pattern p = Pattern.compile("([0-9a-fA-F])([0-9a-fA-F])");
            String[] sMessageStrings = message.split(" ");
            boolean bFlag = false;
            byte[] send = new byte[0];
          //  for (int i = 0; i < sMessageStrings.length; i += REQUEST_CONNECT_DEVICE_SECURE)
            for (int i = 0; i < sMessageStrings.length; i++) {
                if (sMessageStrings[i].length() == REQUEST_CONNECT_DEVICE_INSECURE && this.mConfiguration.getSendHexadecimal()) {
                    Matcher m = p.matcher(sMessageStrings[i]);
                    if (m.find()) {
                        if (i == sMessageStrings.length - 2) {
                            bFlag = true;
                        } else {
                            bFlag = false;
                        }
                        send = Common.Append(send, (byte) Integer.parseInt(m.group(0), 16));
                    } else if (i == 0) {
                        send = Common.Append(send, sMessageStrings[i]);
                    } else {
                        send = Common.Append(send, " " + sMessageStrings[i]);
                    }
                } else if (i == 0 || bFlag) {
                    send = Common.Append(send, sMessageStrings[i]);
                } else {
                    send = Common.Append(send, " " + sMessageStrings[i]);
                }
            }
            /**
             * else if(var3 != 0 && !var2) {
             var7 = Common.Append(var7, " " + var5[var3]);
             } else {
             var7 = Common.Append(var7, var5[var3]);
             }
             */
           // byte[] var8 = send;
            if (mConfiguration.getAppendNewline()) {
                send = Common.Append(send, "\r\n");
            }
            Log.i(Debug.TAG, Common.ByteArrayToHexString(send, send.length, " "));
            mService.write(send);
            mOutStringBuffer.setLength(0);
            mOutEditText.setText(mOutStringBuffer);
        }
    }


    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        switch (requestCode) {
            case REQUEST_CONNECT_DEVICE_SECURE /*1*/:
                if (resultCode == Activity.RESULT_OK ) {
                    connectDevice(data, true);
                }
                break;

            case REQUEST_CONNECT_DEVICE_INSECURE /*2*/:
                if (resultCode ==  Activity.RESULT_OK ) {
                    connectDevice(data, false);
                }
                break;

            case REQUEST_ENABLE_BT /*3*/:
                if (resultCode ==  Activity.RESULT_OK ) {
                    setupService();
                }
                else {
                    // User did not enable Bluetooth or an error occurred
                    Toast.makeText(this, R.string.bt_not_enabled_leaving, LENGTH_SHORT).show();
                    finish();
                }
                // Set up Bluetooth serial port when Bluetooth adapter is turned on


            case REQUEST_SAVE_SETUP /*4*/:
                if (resultCode == RESULT_OK ) {
                    saveSetup(data);
                }
            default:
        }
    }

    private void saveSetup(Intent data) {
        boolean displayHexadecimal = data.getExtras().getBoolean(SetupActivity.EXTRA_DISPLAY_HEXADECIMAL);
        boolean sendHexadecimal = data.getExtras().getBoolean(SetupActivity.EXTRA_SEND_HEXADECIMAL);
        boolean keepScreenOn = data.getExtras().getBoolean(SetupActivity.EXTRA_KEEP_SCREEN_ON);
        new Configuration(this).setValue(displayHexadecimal, sendHexadecimal, keepScreenOn, data.getExtras().getBoolean(SetupActivity.EXTRA_AUTO_APPEND_NEWLINE));
        if (keepScreenOn) {
            getWindow().addFlags(FLAG_KEEP_SCREEN_ON);
        } else {
            getWindow().clearFlags(FLAG_KEEP_SCREEN_ON);
        }
    }

    private void connectDevice(Intent data, boolean secure) {
        // Get the device MAC address
            String address = data.getExtras().getString(DeviceListActivity.EXTRA_DEVICE_ADDRESS);
        // Get the BluetoothDevice object
            BluetoothDevice device = mBluetoothAdapter.getRemoteDevice(address);
            mService.connect(device, secure);

    /*    try {
            //mService.connect(mBluetoothAdapter.getRemoteDevice(data.getExtras().getString(DeviceListActivity.EXTRA_DEVICE_ADDRESS)), secure);
        } catch (IllegalArgumentException e) {
            Toast.makeText(this, R.string.bt_address_invalid, Toast.LENGTH_SHORT).show();
        } */
    }


    public boolean onCreateOptionsMenu(Menu menu) {
        // getMenuInflater().inflate(R.menu.option_menu, menu);
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.option_menu, menu);
        return true;
    }

    public boolean onOptionsItemSelected(MenuItem item) {
        Intent intent = null;

        switch (item.getItemId()) {
            case R.id.secure_connect_scan:
                //startActivityForResult(new Intent(getApplicationContext(), DeviceListActivity.class), REQUEST_CONNECT_DEVICE_SECURE);
                // Launch the DeviceListActivity to see devices and do scan
                intent = new Intent(this, DeviceListActivity.class);
                startActivityForResult(intent, REQUEST_CONNECT_DEVICE_SECURE);
                return true;

            case R.id.insecure_connect_scan:
                //startActivityForResult(new Intent(getApplicationContext(), DeviceListActivity.class), REQUEST_CONNECT_DEVICE_INSECURE);
                // Launch the DeviceListActivity to see devices and do scan
                intent = new Intent(this, DeviceListActivity.class);
                startActivityForResult(intent, REQUEST_CONNECT_DEVICE_INSECURE);
                return true;
            case R.id.discoverable:
                ensureDiscoverable();
                return true;
            case R.id.setup:
                startActivityForResult(new Intent(getApplicationContext(), SetupActivity.class), REQUEST_SAVE_SETUP);
                return true;
            default:
                return false;
        }
    }





    private static class HandlerClass extends Handler {
        private final WeakReference<MainActivity> mTarget;

        public HandlerClass(MainActivity context) {
            mTarget = new WeakReference(context);
        }


        @SuppressWarnings("ResourceType")
        public void handleMessage(Message msg) {
            MainActivity target =  mTarget.get(); //  MainActivity target = (MainActivity) this.mTarget.get();
            BufferedWriter bw;
            switch (msg.what) {
                case STATE_CHANGE /*1*/:
                    switch (msg.arg1) {
                        case NONE:
                        case LISTEN /*1*/:
                            target.setTitle(R.string.title_not_connected);
                            return;
                        case CONNECTING /*2*/:
                            target.setTitle(R.string.title_connecting);
                            return;
                        case CONNECTED /*3*/:
                            target.setTitle(R.string.title_connected_to);
                            target.setTitle(target.getTitle() + " " + target.mConnectedDeviceName);
                            target.mConversationArrayAdapter.clear();
                            return;
                        default:
                            return;
                    }
              //  case REQUEST_CONNECT_DEVICE_INSECURE /*2*/:
                case com.bluetooth.aro.bluetoothterminal2.Bluetooth.Message.READ /*2*/:
                    try {
                    byte[] readBuf = (byte[]) msg.obj;
                    String readMessage = new String(readBuf, 0, msg.arg1);
                    if (target.mConfiguration.getDisplayHexadecimal()) {
                        readMessage = Common.ByteArrayToHexString(readBuf, readBuf.length, " ");
                    }
                    target.mConversationArrayAdapter.add(readMessage.trim(), target.getResources().getColor(R.drawable.blue));
                    target.mConversationView.setAdapter(target.mConversationArrayAdapter);

                        bw = new BufferedWriter(new FileWriter(new File(Environment.getExternalStorageDirectory() + File.separator + ((String) DateFormat.format("yyyyMMdd", new Date())) + ".log"), true));
                        bw.write(new StringBuilder(String.valueOf(readMessage)).append("\r\n").toString(), 0, readMessage.length() + 2);
                        bw.flush();
                        bw.close();
                        return;
                    } catch (Exception e) {
                        Log.d(Debug.TAG, new StringBuilder(String.valueOf((String) DateFormat.format("yyyy-MM-dd kk:mm:ss", new Date()))).append(" ").append("readMessage").append(" ").append(e.toString()).toString());
                        return;
                    }
               // case REQUEST_ENABLE_BT /*3*/:
                case com.bluetooth.aro.bluetoothterminal2.Bluetooth.Message.WRITE /*3*/:
                    byte[] writeBuf = (byte[]) msg.obj;
                    String writeMessage = new String(writeBuf);
                    if (target.mConfiguration.getDisplayHexadecimal()) {
                        writeMessage = Common.ByteArrayToHexString(writeBuf, writeBuf.length, " ");
                    }
                    target.mConversationArrayAdapter.add(writeMessage.trim(), target.getResources().getColor(R.drawable.red));
                    target.mConversationView.setAdapter(target.mConversationArrayAdapter);
                    try {
                        bw = new BufferedWriter(new FileWriter(new File(Environment.getExternalStorageDirectory() + File.separator + ((String) DateFormat.format("yyyyMMdd", new Date())) + ".log"), true));
                        bw.write(new StringBuilder(String.valueOf(writeMessage)).append("\r\n").toString(), 0, writeMessage.length() + 2);
                        bw.flush();
                        bw.close();
                        return;
                    } catch (Exception e2) {
                        Log.d(Debug.TAG, new StringBuilder(String.valueOf((String) DateFormat.format("yyyy-MM-dd kk:mm:ss", new Date()))).append(" ").append("sendMessage").append(" ").append(e2.toString()).toString());
                        return;
                    }

              //  case REQUEST_SAVE_SETUP /*4*/:
                case com.bluetooth.aro.bluetoothterminal2.Bluetooth.Message.DEVICE_NAME /*4*/:
                    //target.mConnectedDeviceName = (String) MainActivity.IsNull(msg.getData().getString(Service.DEVICE_NAME), "none");
                   // target.mConnectedDeviceName = (String) MainActivity.IsNull(msg.getData().getString(com.bluetooth.aro.bluetoothterminal2.Bluetooth.Message.KEY_DEVICE_NAME), "none");

                   // mConnectedDeviceName = msg.getData().getString(KEY_DEVICE_NAME);
                    target.mConnectedDeviceName = msg.getData().getString(com.bluetooth.aro.bluetoothterminal2.Bluetooth.Message.KEY_DEVICE_NAME);
                   // mConnectedDeviceAddress = msg.getData().getString(KEY_DEVICE_ADDRESS);
                    target.mConnectedDeviceAddress = msg.getData().getString(com.bluetooth.aro.bluetoothterminal2.Bluetooth.Message.KEY_DEVICE_ADDRESS);
                    break;

                   /* Toast.makeText(target.getApplicationContext(), "Connected to " + target.mConnectedDeviceName , LENGTH_SHORT).show();
                    return;
*/
                case com.bluetooth.aro.bluetoothterminal2.Bluetooth.Message.TOAST /*5*/:
                    Toast.makeText(target.getApplicationContext(), msg.getData().getString(Service.TOAST), Toast.LENGTH_SHORT).show();
                default:
            }
        }
    }



}
