package com.bluetooth.aro.bluetoothterminal2.Bluetooth;

public class Message {
    public static final int DEVICE_NAME = 4;
    public static final int READ = 2;
    public static final int STATE_CHANGE = 1;
    public static final int TOAST = 5;
    public static final int WRITE = 3;
}
