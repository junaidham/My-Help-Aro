package com.bluetooth.aro.bluetoothterminal2;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.Button;
import android.widget.CheckedTextView;
import android.widget.ListView;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class SetupActivity extends Activity implements OnItemClickListener,OnClickListener{
    public static String EXTRA_AUTO_APPEND_NEWLINE;
    public static String EXTRA_DISPLAY_HEXADECIMAL;
    public static String EXTRA_KEEP_SCREEN_ON;
    public static String EXTRA_SEND_HEXADECIMAL;
    private ArrayList<String> alItem;
    private List<Boolean> listShow;
    private ListView lvSetup;

    /* C00061 : BluetoothTerminal.SetupActivity.1 */
    @Override
    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
        CheckedTextView chkItem = (CheckedTextView) view.findViewById(R.id.ctvItem);
        chkItem.setChecked(!chkItem.isChecked());
        SetupActivity.this.listShow.set(position, Boolean.valueOf(chkItem.isChecked()));

    }


    static {
        EXTRA_DISPLAY_HEXADECIMAL = "display_hexadecimal";
        EXTRA_SEND_HEXADECIMAL = "send_hexadecimal";
        EXTRA_AUTO_APPEND_NEWLINE = "auto_append_newline";
        EXTRA_KEEP_SCREEN_ON = "keep_screen_on";
    }

    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //requestWindowFeature(5);
        requestWindowFeature(Window.FEATURE_INDETERMINATE_PROGRESS);
        setContentView(R.layout.setup_list);

        alItem = new ArrayList();
        alItem.add(0, getResources().getString(R.string.display_hexadecimal));
        alItem.add(1, getResources().getString(R.string.use_hexadecimal));
        alItem.add(2, getResources().getString(R.string.keep_screen_on));
        alItem.add(3, getResources().getString(R.string.append_newline));
        Configuration c = new Configuration(this);
        listShow = new ArrayList();
        listShow.add(0, Boolean.valueOf(c.getDisplayHexadecimal()));
        listShow.add(1, Boolean.valueOf(c.getSendHexadecimal()));
        listShow.add(2, Boolean.valueOf(c.getKeepScreenOn()));
        listShow.add(3, Boolean.valueOf(c.getAppendNewline()));
        lvSetup = (ListView) findViewById(R.id.lvSetup);
        lvSetup.setOnItemClickListener(this);
        ((Button) findViewById(R.id.button_save)).setOnClickListener(this);
        lvSetup.setAdapter(new SetupItemAdapter(this, this.alItem, this.listShow));
    }


    /* C00072  : Qwerty.BluetoothTerminal.SetupActivity.2 */
    @Override
    public void onClick(View v) {

        Intent intent = new Intent();
        intent.putExtra(EXTRA_DISPLAY_HEXADECIMAL, (Serializable) listShow.get(0));
        intent.putExtra(EXTRA_SEND_HEXADECIMAL, (Serializable) listShow.get(1));
        intent.putExtra(EXTRA_KEEP_SCREEN_ON, (Serializable) listShow.get(2));
        intent.putExtra(EXTRA_AUTO_APPEND_NEWLINE, (Serializable) listShow.get(3));
        //setResult(-1, intent);
        setResult(Activity.RESULT_OK, intent);
        finish();

    }


}
