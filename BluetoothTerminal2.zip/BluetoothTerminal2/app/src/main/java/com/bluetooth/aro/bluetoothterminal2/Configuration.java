package com.bluetooth.aro.bluetoothterminal2;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;

import static android.content.Context.MODE_PRIVATE;

public class Configuration {
    private static final String APPEND_NEWLINE = "append_newline";
    private static final String DISPLAY_HEXADECIMAL = "display_hexadecimal";
    private static final String KEEP_SCREEN_ON = "keep_screen_on";
    private static final String PREFERENCE_FILE_NAME = "BluetoothTerminal.dat";
    private static final String SEND_HEXADECIMAL = "send_hexadecimal";
    private SharedPreferences settings;

    public Configuration(Context context) {
        // MODE_PRIVATE - 0
        settings = context.getSharedPreferences(PREFERENCE_FILE_NAME,  MODE_PRIVATE);
    }

    public void setValue(boolean displayHexadecimal, boolean sendHexadecimal, boolean keepScreenOn, boolean autoAppendNewline) {
        Editor PE = settings.edit();
        PE.putBoolean(DISPLAY_HEXADECIMAL, displayHexadecimal);
        PE.putBoolean(SEND_HEXADECIMAL, sendHexadecimal);
        PE.putBoolean(KEEP_SCREEN_ON, keepScreenOn);
        PE.putBoolean(APPEND_NEWLINE, autoAppendNewline);
        PE.commit();
    }

    public boolean getDisplayHexadecimal() {
        return settings.getBoolean(DISPLAY_HEXADECIMAL, false);
    }

    public void setDisplayHexadecimal(boolean displayHexadecimal) {
        Editor PE = settings.edit();
        PE.putBoolean(DISPLAY_HEXADECIMAL, displayHexadecimal);
        PE.commit();
    }

    public boolean getSendHexadecimal() {
        return settings.getBoolean(SEND_HEXADECIMAL, false);
    }

    public void setSendHexadecimal(boolean sendHexadecimal) {
        Editor PE = settings.edit();
        PE.putBoolean(SEND_HEXADECIMAL, sendHexadecimal);
        PE.commit();
    }

    public boolean getKeepScreenOn() {
        return settings.getBoolean(KEEP_SCREEN_ON, false);
    }

    public void setKeepScreenOn(boolean keepScreenOn) {
        Editor PE = settings.edit();
        PE.putBoolean(KEEP_SCREEN_ON, keepScreenOn);
        PE.commit();
    }

    public boolean getAppendNewline() {
        return settings.getBoolean(APPEND_NEWLINE, false);
    }

    public void setAppendNewline(boolean appendNewline) {
        Editor PE = settings.edit();
        PE.putBoolean(APPEND_NEWLINE, appendNewline);
        PE.commit();
    }
}
