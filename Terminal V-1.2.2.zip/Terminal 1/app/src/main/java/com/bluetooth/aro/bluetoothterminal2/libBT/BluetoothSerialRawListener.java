package com.bluetooth.aro.bluetoothterminal2.libBT;

/**
 * Listener for Bluetooth events involving byte arrays in addition to Strings.
 *
 * @author Junaid Ahmad [ junaidhamdard11@gmail.com ]
 */
public interface BluetoothSerialRawListener extends BluetoothSerialListener {

    /**
     * Specified message is read from the serial port.
     *
     * @param bytes The byte array read.
     */
    void onBluetoothSerialReadRaw(byte[] bytes);

    /**
     * Specified message is written to the serial port.
     *
     * @param bytes The byte array written.
     */
    void onBluetoothSerialWriteRaw(byte[] bytes);

}
