package com.bluetooth.aro.bluetoothterminal2.Bluetooth;

import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothManager;
import android.bluetooth.BluetoothServerSocket;
import android.bluetooth.BluetoothSocket;
import android.content.Context;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.os.PowerManager;
import android.util.Log;

import com.bluetooth.aro.bluetoothterminal2.libBT.BluetoothSerialListener;
import com.bluetooth.aro.bluetoothterminal2.libBT.BluetoothSerialRawListener;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
//import java.io.UnsupportedEncodingException;
import java.io.UnsupportedEncodingException;
import java.util.UUID;

//import static android.content.ContentValues.TAG;
import static com.bluetooth.aro.bluetoothterminal2.Bluetooth.Message.*;
import static com.bluetooth.aro.bluetoothterminal2.Bluetooth.State.CONNECTED;
import static com.bluetooth.aro.bluetoothterminal2.Bluetooth.State.CONNECTING;
import static com.bluetooth.aro.bluetoothterminal2.Bluetooth.State.LISTEN;
import static com.bluetooth.aro.bluetoothterminal2.Bluetooth.State.NONE;

public class Service {

    // Debugging
  /*  public static final String TAG = "Bluetooth Service";
    private static final boolean D = true;*/

    public static final String DEVICE_NAME = "device_name";
    private static final int MAX_BUFFER_SIZE =1024;


    // Name for the SDP record when creating server socket
    private static final String NAME_INSECURE = "BluetoothInsecure";
    private static final String NAME_SECURE = "BluetoothSecure";

    // Unique UUID for this application
    private static final UUID UUID_INSECURE;
    private static final UUID UUID_SECURE;

    // Member fields
    public static final String TOAST = "toast";
    private static String data = "";
    private Service.AcceptThread mAcceptThread;
    private BluetoothAdapter mAdapter = BluetoothAdapter.getDefaultAdapter();
    private Service.ConnectThread mConnectThread;
    private Service.ConnectedThread mConnectedThread;
    private Context mContext;
    private Handler mHandler;
    private boolean mSecure;
    private int mState;


  //=====================

    private BluetoothSerialListener mListener;
    private static final String TAG = "BluetoothSerial";
    private Service mService;

    public static boolean isRaw;


    public Service(Context context, BluetoothSerialListener listener) {
        mAdapter = getAdapter(context);
        mListener = listener;
        isRaw = mListener instanceof BluetoothSerialRawListener;
    }

    public static BluetoothAdapter getAdapter(Context context) {
        BluetoothAdapter bluetoothAdapter = null;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR2) {
            BluetoothManager bluetoothManager = (BluetoothManager) context.getSystemService(Context.BLUETOOTH_SERVICE);
            if (bluetoothManager != null)
                bluetoothAdapter = bluetoothManager.getAdapter();
        } else {
            bluetoothAdapter = BluetoothAdapter.getDefaultAdapter();
        }
        return bluetoothAdapter;
    }


    public boolean isBluetoothEnabled() {
        return mAdapter.isEnabled();
    }
    public boolean checkBluetooth() {
        if (mAdapter == null) {
            mListener.onBluetoothNotSupported();
            return false;
        } else {
            if (!mAdapter.isEnabled()) {
                mListener.onBluetoothDisabled();
                return false;
            } else {
                return true;
            }
        }
    }
    public void connect(String address) {
        BluetoothDevice device = null;
        try {
            device = mAdapter.getRemoteDevice(address);
        } catch (IllegalArgumentException e) {
            Log.e(TAG, "Device not found!");
        }
        if (device != null)
            connect(device);
    }
    public void connect(BluetoothDevice device) {
        if (mService != null) {
            mService.connect(device);
        }
    }

    public String getLocalAdapterName() {
        return mAdapter.getName();
    }
    public String getLocalAdapterAddress() {
        return mAdapter.getAddress();
    }

    // ====================



    static {
        UUID_SECURE = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB");
        UUID_INSECURE = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB");
        data = "";
    }

    public Service(Context context, Handler handler) {
        mAdapter = BluetoothAdapter.getDefaultAdapter();
        mState = NONE;
        mContext = context;
        mHandler = handler;
    }




    /**
     * This thread runs while listening for incoming connections. It behaves
     * like a server-side client. It runs until a connection is accepted
     * (or until cancelled).
     */
    private class AcceptThread extends Thread {
        // The local server socket
        private String mSocketType;
        private BluetoothServerSocket mmServerSocket;

        // Create a new listening server socket
        public AcceptThread(boolean secure) {
            BluetoothServerSocket tmp = null;
           mSocketType = secure ? "Secure" : "Insecure";

            // Create a new listening server socket
            try {
                if (secure) {
                    tmp = mAdapter.listenUsingRfcommWithServiceRecord(NAME_SECURE, UUID_SECURE);
                } else {
                    tmp = mAdapter.listenUsingInsecureRfcommWithServiceRecord(NAME_INSECURE, UUID_INSECURE);
                }
            } catch (Exception e) {
                Log.e(Debug.TAG, "Socket Type: " + this.mSocketType + "listen() failed", e);
            }

            mmServerSocket = tmp;
        }


      public void run() {
          Log.e(Debug.TAG, "Socket Type: " + mSocketType + "BEGIN mAcceptThread" + this);
          setName("AcceptThread" + mSocketType);
          Log.e(Debug.TAG, "Made it to run thread");
         // BluetoothSocket socket = null;
          // Listen to the server socket if we're not connected
          BluetoothSocket socket = null;

          while (mState != CONNECTED) {
              try {
                  // This is a blocking call and will only return on a
                  // successful connection or an exception
                 // if (socket != null)
                  if (mmServerSocket != null) {
                      socket = mmServerSocket.accept();
                  }
              } catch (IOException e) {
                  Log.e(Debug.TAG, "Socket Type: " + mSocketType + "accept() failed: "+e.getMessage());
              }
              // If a connection was accepted
              if (socket != null) {
                  synchronized (this) {
                      switch (mState) {
                          // Either not ready or already connected. Terminate new socket.
                          case NONE:
                          case CONNECTED:
                              try {
                                  socket.close();
                              } catch (Exception e) {
                                  Log.e(Debug.TAG, "Could not close unwanted socket", e);
                              }
                              break;

                          case LISTEN:
                          case CONNECTING:
                              // Situation normal. Start the connected thread.
                              connected(socket, socket.getRemoteDevice(), mSocketType);
                              // Service.this.connected(socket, socket.getRemoteDevice(), this.mSocketType);
                              break;
                      }
                  }
              }
          }
          Log.e(Debug.TAG, "END mAcceptThread, socket Type: " + mSocketType);

          //throw new UnsupportedOperationException("Method not decompiled: Bluetooth.Service.AcceptThread.run():void");
      }

        public void cancel() {
            if (mmServerSocket != null) {
                try {
                    mmServerSocket.close();
                } catch (Exception e) {
                    Log.e(Debug.TAG, "Socket Type" + this.mSocketType + "close() of server failed", e);
                }
                mmServerSocket = null;
            }
        }


       /* public void cancel() {
            try {
                this.mmServerSocket.close();
            } catch (Exception e) {
                Log.e(Debug.TAG, "Socket Type" + this.mSocketType + "close() of server failed", e);
            }
        }

*/

    } // end AcceptThread


    /**
     * This thread runs while attempting to make an outgoing connection
     * with a device. It runs straight through; the connection either
     * succeeds or fails.
     */

    private class ConnectThread extends Thread {
        private String mSocketType;
        private final BluetoothDevice mmDevice;
        private final BluetoothSocket mmSocket;

        public ConnectThread(BluetoothDevice device, boolean secure) {
             mmDevice = device;
            BluetoothSocket tmp = null;

            // Get a BluetoothSocket for a connection with the given BluetoothDevice , device to secure and unsecure
            Log.e(Debug.TAG, "Connect thread constructor");
            try {
                 mSocketType = secure ? "Secure" : "Insecure";
                if (secure) {
                    tmp = device.createRfcommSocketToServiceRecord(Service.UUID_SECURE);
                      Log.e(Debug.TAG, "Created secure socket to "+UUID_SECURE);
                } else {
                    tmp = device.createInsecureRfcommSocketToServiceRecord(Service.UUID_INSECURE);
                       Log.e(Debug.TAG, "Created insecure socket to "+UUID_SECURE);
                }

            }catch (IOException e) {
                Log.e(Debug.TAG, "Socket Type: " + mSocketType + "create() failed", e);
            }
             mmSocket = tmp;
        }


        @SuppressWarnings("WrongConstant")
        public void run() {
            Log.i(Debug.TAG, "BEGIN mConnectThread SocketType:" + mSocketType);
            setName("ConnectThread" + mSocketType);

            // Always cancel discovery because it will slow down a connection
            //Service.this.mAdapter.cancelDiscovery();

            mAdapter.cancelDiscovery();
            // Listen to the server socket if we're not connected
            // Make a connection to the BluetoothSocket   - getSystemService("power")).isScreenOn();
            try {

                boolean isScreenOn = ((PowerManager) mContext.getSystemService("power")).isScreenOn();
                if (mmSocket.isConnected() || !isScreenOn) {
                    mmSocket.close();
                }
                // This is a blocking call and will only return on a
                // successful connection or an exception
                mmSocket.connect();


            } catch (Exception e) {
                try {
                    mmSocket.close();
                } catch (Exception e2) {
                    Log.e(Debug.TAG, "unable to close() " + mSocketType + " socket during connection failure", e2);
                }
                connectionFailed();
                return;
            }

            // Reset the ConnectThread because we're done
              synchronized (Service.this) {
                    mConnectThread = null;
                }
                connected(mmSocket,mmDevice, mSocketType);

            /*synchronized (Service.this) {
                // Reset the ConnectThread because we're done
                Service.this.mConnectThread = null;
            }
            Service.this.connected(this.mmSocket, this.mmDevice, this.mSocketType);
*/

        }



        public void cancel() {
            try {
                mmSocket.close();
            } catch (Exception e) {
                Log.e(Debug.TAG, "close() of connect " + mSocketType + " socket failed", e);
            }
        }
    }


    /**
     * This thread runs during a connection with a remote device.
     * It handles all incoming and outgoing transmissions.
     */
    private class ConnectedThread extends Thread {
        private final InputStream mmInStream;
        private final OutputStream mmOutStream;
        private final BluetoothSocket mmSocket;

        public ConnectedThread(BluetoothSocket socket, String socketType) {
            Log.d(Debug.TAG, "create ConnectedThread: " + socketType);
            this.mmSocket = socket;
            InputStream tmpIn = null;
            OutputStream tmpOut = null;

            // Get the BluetoothSocket input and output streams
            try {
                tmpIn = socket.getInputStream();
                tmpOut = socket.getOutputStream();
            } catch (Exception e) {
                Log.e(Debug.TAG, "temp sockets not created", e);
            }
            this.mmInStream = tmpIn;
            this.mmOutStream = tmpOut;
        }



        public void run() {

            byte[] data = new byte[MAX_BUFFER_SIZE];
            int length;

            while (true) {
                try {
                    length = mmInStream.read(data);
                    byte[] read = new byte[length];
                    System.arraycopy(data, 0, read, 0, length);
                    mHandler.obtainMessage(READ, length, -1, read).sendToTarget();
                } catch (IOException e) {
                    //reconnect(); // Connection lost
                    Service.this.connectionLost();
                    break;
                }
            }



       /*     Log.i(Debug.TAG, "BEGIN mConnectedThread");
            byte[] buffer = new byte[MAX_BUFFER_SIZE];

            // Keep listening to the InputStream while connecte
            while (true) {
                try {
                    data = data + new String(buffer, "ISO-8859-1").substring(0, mmInStream.read(buffer));
                } catch (IOException e) {
                    e.printStackTrace();
                }
                data = data.replaceAll("\r\n", "\r").replaceAll("\n", "\r");
                    if (Service.data.contains("\r\n") || data.length() > MAX_BUFFER_SIZE) {
                        if (data.contains("\r")) {
                            try {
                                mHandler.obtainMessage(READ, data.lastIndexOf("\r"), -1, data.substring(0, data.lastIndexOf("\r") + 1).getBytes("ISO-8859-1")).sendToTarget();
                            } catch (UnsupportedEncodingException e) {

                            }

                            data = data.substring(data.lastIndexOf("\r") + 1);
                        } else {
                            try {
                                if (data.length() > MAX_BUFFER_SIZE) {
                                    mHandler.obtainMessage(READ, data.length(), -1, data.getBytes("ISO-8859-1")).sendToTarget();
                                    data = "";
                                }
                            } catch (Exception e) {
                                Log.e(Debug.TAG, "disconnected", e);
                                Service.this.connectionLost();
                                return;
                            }
                        }
                    }

            }

            */



           /* while (true) {
                try {
                    // Let client handle data
                   data = data + new String(buffer, "ISO-8859-1").substring(0, mmInStream.read(buffer));
                } catch (IOException e) {
                    e.printStackTrace();
                }
                data = data.replaceAll("\r\n", "\r").replaceAll("\n", "\r");
                if (data.contains("\r") || data.length() > Service.MAX_BUFFER_SIZE) {
                    if (data.contains("\r")) {
                        try {
                            mHandler.obtainMessage(2, data.lastIndexOf("\r"), -1, data.substring(0, data.lastIndexOf("\r") + 1).getBytes("ISO-8859-1")).sendToTarget();
                        } catch (UnsupportedEncodingException e) {
                            e.printStackTrace();
                        }
                        data = data.substring(data.lastIndexOf("\r") + 1);
                    } else {
                        try {
                            if (data.length() > MAX_BUFFER_SIZE) {
                                mHandler.obtainMessage(2, data.length(), -1, data.getBytes("ISO-8859-1")).sendToTarget();
                                data = "";
                            }
                        } catch (Exception e) {
                            Log.e(Debug.TAG, "disconnected", e);
                           connectionLost();
                            return;
                        }
                    }
                }
            }
            */


        }

        public void write(byte[] buffer) {
            try {
                mmOutStream.write(buffer);
                mHandler.obtainMessage(WRITE, -1, -1, buffer).sendToTarget(); //3 -> MESSAGE_WRITE
            } catch (Exception e) {
                Log.e(Debug.TAG, "Exception during write", e);
            }
        }

        public void cancel() {
            try {
                mmSocket.close();
            } catch (Exception e) {
                Log.e(Debug.TAG, "close() of connect socket failed", e);
            }
        }
    }


    // Return the current connection state.
   /* private void setState(int state) {
        synchronized (this) {
            this.mState = state;
            this.mHandler.obtainMessage(1, state, -1).sendToTarget();
            return ;
        }
    }*/

    private synchronized void setState(int state) {
        mState = state;
        mHandler.obtainMessage(STATE_CHANGE, state, -1).sendToTarget();
    }
    public synchronized int getState() {
        return mState;
    }

    // Start the chat service. Specifically start AcceptThread to begin a
    // session in listening (server) mode. Called by the Activity onResume()
    public synchronized void start() {
        // Cancel any thread attempting to make a connection
        if (mConnectThread != null) {
            mConnectThread.cancel();
            mConnectThread = null;
        }
        // Cancel any thread currently running a connection
        if (mConnectedThread != null) {
            mConnectedThread.cancel();
            mConnectedThread = null;
        }
        //setState(1);
        setState(State.LISTEN);

        if (mAcceptThread == null) {
            mAcceptThread = new AcceptThread(mSecure);
            mAcceptThread.start();
        }
    }


    /**
     * Start the ConnectThread to initiate a connection to a remote device.
     * @param device  The BluetoothDevice to connect
     * @param secure Socket Security type - Secure (true) , Insecure (false)
     */
    public synchronized void connect(BluetoothDevice device, boolean secure) {
        mSecure = secure;
        if (mConnectThread != null) {
            mConnectThread.cancel();
            mConnectThread = null;
        }
        if (mConnectedThread != null) {
            mConnectedThread.cancel();
            mConnectedThread = null;
        }
        mConnectThread = new ConnectThread(device, mSecure);
        mConnectThread.start();

        //setState(2);
        setState(State.CONNECTING);
    }


    /**
     *
     * @return true if paired device with matching BDADDR was found, false otherwise
     */
    public synchronized void connected(BluetoothSocket socket, BluetoothDevice device, String socketType) {
        if (mConnectThread != null) {
            mConnectThread.cancel();
            mConnectThread = null;
        }
        if (mConnectedThread != null) {
            mConnectedThread.cancel();
            mConnectedThread = null;
        }
        if (mAcceptThread != null) {
            mAcceptThread.cancel();
            mAcceptThread = null;
        }

        mConnectedThread = new ConnectedThread(socket, socketType);
        mConnectedThread.start();
        Message msg = mHandler.obtainMessage(4);
        Bundle bundle = new Bundle();
        bundle.putString(DEVICE_NAME, device.getName());
        msg.setData(bundle);
        mHandler.sendMessage(msg);

        //setState(3);
        setState(State.CONNECTED);
    }

    public synchronized void stop() {
        if (mConnectThread != null) {
            mConnectThread.cancel();
            mConnectThread = null;
        }
        if (mConnectedThread != null) {
            mConnectedThread.cancel();
            mConnectedThread = null;
        }
        if (mAcceptThread != null) {
            mAcceptThread.cancel();
            mAcceptThread = null;
        }
        //setState(0);
        setState(State.NONE);
    }

    public void write(byte[] out) {
        synchronized (this) {
            if (mState != CONNECTED) {
                return;
            }
            ConnectedThread r = mConnectedThread;
            r.write(out);
        }
    }

    private void connectionFailed() {
        Message msg = mHandler.obtainMessage(5);
        Bundle bundle = new Bundle();
        bundle.putString(TOAST, "Unable to connect device");
        msg.setData(bundle);
        mHandler.sendMessage(msg);
        start();
    }

    private void connectionLost() {
        Message msg = mHandler.obtainMessage(5);
        Bundle bundle = new Bundle();
        bundle.putString(TOAST, "Device connection was lost");
        msg.setData(bundle);
        mHandler.sendMessage(msg);
        start();
    }


}
