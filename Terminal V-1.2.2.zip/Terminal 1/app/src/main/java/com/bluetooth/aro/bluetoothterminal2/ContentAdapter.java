package com.bluetooth.aro.bluetoothterminal2;

import android.content.Context;
import android.graphics.Typeface;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;
import java.util.ArrayList;

public class ContentAdapter extends BaseAdapter {
    private ArrayList<Message> Messages;
    private LayoutInflater mInflater;

    private class Message {
        private String mContent;
        private int mState;

        public Message(String Content, int State) {
            mContent = "";
            mState = 0;
            this.mContent = Content;
            this.mState = State;
        }

        public String getContent() {
            return mContent;
        }

        public int getState() {
            return mState;
        }
    }

    public ContentAdapter(Context context) {
        mInflater = LayoutInflater.from(context);
        Messages = new ArrayList();
    }

    public int getCount() {
        return Messages.size();
    }

    public Message getItem(int position) {
        return Messages.get(position);
    }

    public void clear() {
        if (Messages != null) {
            Messages.clear();
        }
    }

    public long getItemId(int position) {
        return (long) position;
    }

    public View getView(int position, View convertView, ViewGroup parent) {
        TextView mText;
        if (convertView == null) {
            convertView = mInflater.inflate(R.layout.message, null);
            mText = (TextView) convertView.findViewById(R.id.tvContent);
            convertView.setTag(mText);
        } else {
            mText = (TextView) convertView.getTag();
        }
        //mText.setText(((Message) Messages.get(position)).getContent());
        mText.setText(((Message) Messages.get(position)).getContent());
        mText.setTypeface(Typeface.MONOSPACE);
        mText.setTextColor(((Message) Messages.get(position)).getState());
        return convertView;
    }

    public void add(String content, int state) {
        Messages.add(new Message(content, state));
    }
}
