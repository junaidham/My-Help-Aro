package com.bluetooth.aro.bluetoothterminal2;

public class Debug {
    public static final boolean Data = true;
    public static final boolean Effect = false;
    public static final boolean Enable = true;
    public static final String TAG = "BluetoothTerminal";

    public static boolean Enable() {
        return true;
    }
}
