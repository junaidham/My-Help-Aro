package com.bluetooth.aro.bluetoothterminal2.Bluetooth;

import java.math.BigInteger;
import java.util.Locale;

public class Common {
    public static String ByteArrayToHexString(byte[] Content, int Length, String GapWord) {
        String Ret = "";
        for (int i = 0; i < Length; i++) {
            StringBuilder stringBuilder = new StringBuilder(String.valueOf(Ret));
            String toHexString = Integer.toHexString(Content[i] & 255) == "0" ? "00" : Integer.toHexString(Content[i] & 255).length() == 1 ? "0" + Integer.toHexString(Content[i] & 255) : Integer.toHexString(Content[i] & 255);
            Ret = stringBuilder.append(toHexString.toUpperCase(Locale.ENGLISH)).append(GapWord).toString();
        }
        return Ret;
    }

    public static String toHexString(byte[] in) {
        return new BigInteger(in).toString(16);
    }

    public static byte[] fromHexString(String in) {
        return new BigInteger(in, 16).toByteArray();
    }

    public static byte[] Append(byte[] Source, String New) {
        return Append(Source, New.getBytes());
    }

    public static byte[] Append(byte[] Source, byte New) {
        return Append(Source, new byte[]{New});
    }

    public static byte[] Append(byte[] Source, byte[] New) {
        byte[] Result = new byte[(Source.length + New.length)];
        System.arraycopy(Source, 0, Result, 0, Source.length);
        System.arraycopy(New, 0, Result, Source.length, New.length);
        return Result;
    }

    public static int UnsignedByte(byte b) {
        return b & 255;
    }

    public static int ByteArrayToInt(byte[] b) {
        int n = 0;
        for (byte b2 : b) {
            n = (n << 8) | (b2 & 255);
        }
        return n;
    }
}
