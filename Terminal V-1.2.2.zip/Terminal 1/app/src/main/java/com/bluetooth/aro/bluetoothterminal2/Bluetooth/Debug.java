package com.bluetooth.aro.bluetoothterminal2.Bluetooth;

public class Debug {
    public static final boolean Enabled = false;
    public static final String TAG = "Bluetooth Service";
   // public static final boolean D = true;  // D [ true ]-> Enabled [false]

}
